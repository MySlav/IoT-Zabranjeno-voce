package banana.co;

public interface ILoadMore {
    public void onLoadMore();
}
